// | Project : event_detectItem
// | Author : Aoki
// | Description : Detects a Brick's Item via Events

function detectItem_assembleEvents()
{
	registerOutputEvent("fxDTSBrick", "detectItem", "datablock ItemData");
	registerInputEvent("fxDTSBrick", "onItemDecTrue", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection");
	registerInputEvent("fxDTSBrick", "onItemDecFalse", "Self fxDTSBrick" TAB "Player Player" TAB "Client GameConnection");
}

function fxDTSBrick::detectItem(%brick, %image, %client)
{
	if(isObject(%client.player) && isObject(%image) && isObject(%brick))
	{
		if(%brick.item.dataBlock.getName() $= %image.getName())
			%brick.onItemDecTrue(%client);
		else
			%brick.onItemDecFalse(%client);
	}
}

function fxDTSBrick::onItemDecTrue(%brick, %client)
{
	$inputTarget_self		= %brick;
	$inputTarget_player	= %client.player;
	$inputTarget_client	= %client;

	%brick.processInputEvent("onItemDecTrue", %client);
}

function fxDTSBrick::onItemDecFalse(%brick, %client)
{
	$inputTarget_self		= %brick;
	$inputTarget_player	= %client.player;
	$inputTarget_client	= %client;

	%brick.processInputEvent("onItemDecFalse", %client);
}

detectItem_assembleEvents();