//+--
//Project: PetMod; Script_PetMod.cs
//Description: The main .cs file that houses all the important functions.
//Authors: halcynthis, Aoki, Fooly Cooly, Jookia for the the timeout code.
//+--
$PetMod_TimeOut = 3;
//Section One: Server Commands

function servercmdGetDog(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	for(%a = 0; getSubStr(%petName, %a, 1) !$= ""; %a++)
	{
		if(getSubStr(%petName, %a, 1) || getSubStr(%petName, %a, 1) $= "0")
		{
			messageClient(%client, '', "\c6You can not have numbers in your pets name.");
			return;
		}
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName.Owner !$= "")
	{
		messageClient(%client, '', "\c6There is already a pet named\c3 "@%petName);
		return;
	}

	if(%client.pets >= 5)
	{
		messageClient(%client, '', "\c6You may only have five pets.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	messageClient(%client, '', "\c6You adopted a pet and named him \c3" @ %petName @ "\c6.");

	new AIPlayer(%petName)
	{
		datablock = "PetArmor";
		position = %client.player.getPosition();
	};
	
	%petName.Owner = %client.netName;
	%petName.petName = %petName;
	%petName.setScale("0.4 0.4 0.4");
	%petName.setMoveObject(%client.player);
	%petName.mountimage(DogImage, 1);
	%petName.hideNode(body);
	%petName.hideNode(head);
	%petName.isPet = 1;
	%client.pets += 1;
	%client.pet[%client.pets] = %petName;
	%client.lastCommandSent = $sim::time;
}

function servercmdGetMonkey(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	for(%a = 0; getSubStr(%petName, %a, 1) !$= ""; %a++)
	{
		if(getSubStr(%petName, %a, 1) || getSubStr(%petName, %a, 1) $= "0")
		{
			messageClient(%client, '', "\c6You can not have numbers in your pets name.");
			return;
		}
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName.Owner !$= "")
	{
		messageClient(%client, '', "\c6There is already a pet named\c3 " @ %petName);
		return;
	}

	if(%client.pets >= 5)
	{
		messageClient(%client, '', "\c6You may only have five pets.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	messageClient(%client, '', "\c6You adopted a pet and named him \c3" @ %petName @ "\c6.");

	new AIPlayer(%petName)
	{
		datablock = "PetArmor";
		position = %client.player.getPosition();
	};

	%petName.Owner = %client.netName;
	%petName.petName = %petName;
	%petName.setScale("0.5 0.5 0.5");
	%petName.setMoveObject(%client.player);
	%petName.mountimage(MonkeyImage, 1);
	%petName.hideNode(body);
	%petName.hideNode(head);
	%client.pets += 1;
	%client.pet[%client.pets] = %petName;
	%client.lastCommandSent = $sim::time;
}

function servercmdGetHorse(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	for(%a = 0; getSubStr(%petName, %a, 1) !$= ""; %a++)
	{
		if(getSubStr(%petName, %a, 1) || getSubStr(%petName, %a, 1) $= "0")
		{
			messageClient(%client, '', "\c6You can not have numbers in your pets name.");
			return;
		}
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName.Owner !$= "")
	{
		messageClient(%client, '', "\c6There is already a pet named\c3 "@%petName);
		return;
	}

	if(%client.pets >= 5)
	{
		messageClient(%client, '', "\c6You may only have five pets.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	messageClient(%client, '', "\c6You adopted a pet and named him \c3"@%petName@"\c6.");

	new AIPlayer(%petName)
	{
		datablock = "HorseArmor";
		position = %client.player.getPosition();
	};

	%petName.Owner = %client.netName;
	%petName.petName = %petName;
	%petName.setScale("0.4 0.4 0.4");
	%petName.setMoveObject(%client.player);
	%client.pets += 1;
	%client.pet[%client.pets] = %petName;
	%client.lastCommandSent = $sim::time;
}

function servercmdGetChild(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	for(%a = 0; getSubStr(%petName, %a, 1) !$= ""; %a++)
	{
		if(getSubStr(%petName, %a, 1) || getSubStr(%petName, %a, 1) $= "0")
		{
			messageClient(%client, '', "\c6You can not have numbers in your pets name.");
			return;
		}
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName.Owner !$= "")
	{
		messageClient(%client, '', "\c6There is already a child named\c3 "@%petName);
		return;
	}

	if(%client.pets >= 5)
	{
		messageClient(%client, '', "\c6You may only have five pets or children.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a child name.");
		return;
	}

	messageClient(%client, '', "\c6You adopted a child and named him \c3"@%petName@"\c6.");

	new AIPlayer(%petName)
	{
		datablock = "PlayerStandardArmor";
		position = %client.player.getPosition();
	};

	%petName.Owner = %client.netName;
	%petName.petName = %petName;
	%petName.setScale("0.6 0.6 0.6");
	%petName.setMoveObject(%client.player);
	%client.pets += 1;
	%client.pet[%client.pets] = %petName;
	%client.lastCommandSent = $sim::time;
}

function servercmdGetSkeleton(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	for(%a = 0; getSubStr(%petName, %a, 1) !$= ""; %a++)
	{
		if(getSubStr(%petName, %a, 1) || getSubStr(%petName, %a, 1) $= "0")
		{
			messageClient(%client, '', "\c6You can not have numbers in your pets name.");
			return;
		}
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName.Owner !$= "")
	{
		messageClient(%client, '', "\c6There is already a pet named\c3 "@%petName);
		return;
	}

	if(%client.pets >= 5)
	{
		messageClient(%client, '', "\c6You may only have five pets.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	messageClient(%client, '', "\c6You adopted a pet and named him \c3"@%petName@"\c6.");

	new AIPlayer(%petName)
	{
		datablock = "PlayerStandardArmor";
		position = %client.player.getPosition();
	};

	%petName.Owner = %client.netName;
	%petName.petName = %petName;
	%petName.setScale("0.6 0.6 0.6");
	%petName.setMoveObject(%client.player);

	ClearAllPlayerNodes(%petName);

	%petName.unhideNode(RHand);
	%petName.unhideNode(LHand);
	%petName.unhideNode(RArmSlim);
	%petName.unhideNode(LArmSlim);
	%petName.unhideNode(RShoe);
	%petName.unhideNode(LShoe);
	%petName.larmColor = "1 1 1 1";
	%petName.llegColor = "1 1 1 1";
	%petName.rarmColor = "1 1 1 1";
	%petName.rlegColor = "1 1 1 1";
	%petName.rhandColor = "1 1 1 1";
	%petName.lhandColor = "1 1 1 1";
	%petName.setNodeColor(RHand, "1 1 1 1");
	%petName.setNodeColor(LHand, "1 1 1 1");
	%petName.setNodeColor(RArmSlim, "1 1 1 1");
	%petName.setNodeColor(LArmSlim, "1 1 1 1");
	%petName.setNodeColor(RShoe, "1 1 1 1");
	%petName.setNodeColor(LShoe, "1 1 1 1");
	%petName.mountImage(SkeleHeadImage, 2);
	%petName.mountImage(SkeleBodyImage, 1);

	%client.pets += 1;
	%client.pet[%client.pets] = %petName;
	%client.lastCommandSent = $sim::time;
}

function servercmdKillPet(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	if(%petName $= "All")
	{
		for(%i = 1; %i <= %client.pets; %i++)
		{
			if(!isObject(%client.pet[%i]))
				continue;

			%client.pet[%i].delete();
			%client.pet[%i] = "";
		}
		%client.pets = 0;
		messageClient(%client, '', "\c6Being the aweful human being that you are, you kill all of your pets.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	if(%petName.Owner !$= %client.netName)
	{
		messageClient(%client, '', "\c3"@%petName@"\c6 is not your pet.");
		return;
	}

	messageClient(%client, '', "\c6Being the aweful human being that you are, you killed your poor pet\c3 "@%petName@"\c6.");

	for(%a = 0; %a <= %client.pets; %a++)
	{
		if(%client.pet[%a] $= %petName)
		{
			%foundPet = true;
			%client.pet[%a].delete();
			%client.pet[%a] = "";
			continue;
		}

		if(%foundPet)
		{
			%client.pet[%a - 1] = %client.pet[%a];
			%client.pet[%a] = "";
		}
	}

	if(%foundPet)
		%client.pets--;

	%client.lastCommandSent = $sim::time;
}

function servercmdStay(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	if(%petName.Owner !$= %client.netName)
	{
		messageClient(%client, '', "\c3"@%petName@"\c6 is not your pet.");
		return;
	}

	messageClient(%client, '', "\c6You asked your pet\c3 "@%petName@"\c6 to stay!");
	%petName.setMoveObject("");
	%client.lastCommandSent = $sim::time;
}

function servercmdFollow(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	if(%petName.Owner !$= %client.netName)
	{
		messageClient(%client, '', "\c3"@%petName@"\c6 is not your pet.");
		return;
	}

	messageClient(%client, '', "\c6You asked your pet\c3 "@%petName@"\c6 to follow!");
	%petName.setMoveObject(%client.player);
	%client.lastCommandSent = $sim::time;
}

function servercmdListPets(%client)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	if(%client.pet[1] $= "" && %client.pet[2] $= "" && %client.pet[3] $= "" && %client.pet[4] $= "" && %client.pet[5] $= "")
	{
		messageClient(%client, '', "\c6You have no pets.");
		return;
	}

	messageClient(%client, '', "\c6Here is a list of all your pets.");

	for(%i = 1; %i <= %client.pets; %i++)
		messageClient(%client, '', "\c3" @ %client.pet[%i]);

	%client.lastCommandSent = $sim::time;
}

function servercmdFetchPet(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	if(%petName.Owner !$= %client.netName)
	{
		messageClient(%client, '', "\c3"@%petName@"\c6 is not your pet.");
		return;
	}

	messageClient(%client, '', "\c6You fetched your pal \c3"@%petName@"\c6.");
	%petName.setTransform(%client.player.getPosition());
	%client.lastCommandSent = $sim::time;
}

function servercmdControl(%client, %petName)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	if(!isObject(%client.player))
	{
		messageClient(%client, '', "\c6Spawn first before using this command.");
		return;
	}

	if(%petName $= "")
	{
		%client.setControlObject(%client.player);
		return;
	}

	if(%petName.Owner !$= %client.netName)
	{
		messageClient(%client, '', "\c3"@%petName@"\c6 is not your pet.");
		return;
	}

	messageClient(%client, '', "\c6You took control of \c3"@%petName@"\c6.");
	%client.setControlObject(%petName);
	%client.lastCommandSent = $sim::time;
}

function servercmdResize(%client, %petName, %x, %y, %z)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	if(%petName $= "")
	{
		messageClient(%client, '', "\c6Please enter a pet name.");
		return;
	}

	if(%petName.Owner !$= %client.netName)
	{
		messageClient(%client, '', "\c3"@%petName@"\c6 is not your pet.");
		return;
	}

	if(%x >= 1)
		%x = 0.7;
	if(%y >= 1)
		%y = 0.7;
	if(%z >= 1)
		%z = 0.7;

	if(%x < 0.3)
		%x = 0.3;
	if(%y < 0.3)
		%y = 0.3;
	if(%z < 0.3)
		%z = 0.3;

	messageClient(%client, '', "\c6You resized your pet\c3" SPC %petName @ "\c6.");
	%petName.setScale(%x SPC %y SPC %z);
	%client.lastCommandSent = $sim::time;
}

function servercmdPetHelp(%client)
{
	if(%client.lastCommandSent + $PetMod_TimeOut > $sim::time)
	{
		messageClient(%client, '', "\c6To prevent command flooding, your message has been blocked. Try again in" SPC mFloor((%client.lastCommandSent + 5) - $sim::time) SPC "seconds.");
		return;
	}

	messageClient(%client, '', "\c6Welcome to PetMod!\c3 Here are all the server commands you are able to use.");
	messageClient(%client, '', "\c3/getDog\c2 NAME\c6 - Gives you a pet Dog.");
	messageClient(%client, '', "\c3/getMonkey\c2 NAME\c6 - Gives you a pet Monkey.");
	messageClient(%client, '', "\c3/getHorse\c2 NAME\c6 - Gives you a pet Horse.");
	messageClient(%client, '', "\c3/getSkeleton\c2 NAME\c6 - Gives you a pet Skeleton.");
	messageClient(%client, '', "\c3/getChild\c2 NAME\c6 - Gives you a small child.");
	messageClient(%client, '', "\c0/killPet\c2 NAME \c6 - Deletes any given pet. (say \"ALL\" to delete all of them)");
	messageClient(%client, '', "\c3/stay\c2 NAME \c6 - Makes the pet stop following you.");
	messageClient(%client, '', "\c3/follow\c2 NAME \c6 - makes the pet start following you.");
	messageClient(%client, '', "\c3/listPets\c6 - Lists all your current pets.");
	messageClient(%client, '', "\c3/fetchPet\c2 NAME \c6 - transports your pet to your current location.");
	messageClient(%client, '', "\c3/control\c2 NAME \c6 - Controls your pet, leave the name blank to control yourself.");
	messageClient(%client, '', "\c3/resize \c2 NAME, X, Y, Z \c6 - Resizes your pet. (only factors between 0.3 and 0.7 work)");
	messageClient(%client, '', "\c7END OF HELP");
	%client.lastCommandSent = $sim::time;
}


