// < +------------------------------------------------------------+ >
// | Project: server_tools : server.cs
// | Description: Extra functionality for server projects.
// | Author: log (48829)
// < +------------------------------------------------------------+ >

// < +------------------------------------------------------------+ >
// | Table of Contents
// | 1. Prefs
// | 2. Supporting Functions
// | 3. Package
// | 4. Admin/Super Admin Chat
// | 5. Brick Commands
// | 6. Help Command
// | 7. Logs
// | 8. Muting
// | 9. PSAs
// | 10. Voting
// < +------------------------------------------------------------+ >

// < +------------------------------------------------------------+ >
// | Section 1: Prefs
// < +------------------------------------------------------------+ >

if(isFile("Add-ons/System_ReturnToBlockland/server.cs"))
{
	if(!$LST::PrefsLoaded)
	{
		if(!$RTB::RTBR_ServerControl_Hook)
			exec("Add-Ons/System_ReturnToBlockland/hooks/serverControl.cs");

		RTB_registerPref("Minimum Announcement Time", "log's Server Tools", "$LST::MinimumPSATime", "int", "server_tools", 3, 0, 0);
		RTB_registerPref("EVAL Prefix", "log's Server Tools", "$LST::Prefix", "string 8", "server_tools", "-", 0, 0);
		RTB_registerPref("Second Welcome Message", "log's Server Tools", "$LST::SecondWelcomeMessage", "server_tools", "", 0, 0);
		$LST::PrefsLoaded = 1;
	}
}
else
{
	if(isFile("config/server/lst.cs"))
		exec("config/server/lst.cs");
	else
	{
		$LST::MinimumAnnouncementTime = 3;
		$LST::Prefix = "-";
		$LST::SecondWelcomeMessage = "";
		export("$LST::*", "config/server/lst.cs"); 
	}
}

// < +------------------------------------------------------------+ >
// | Section 2: Supporting Functions
// < +------------------------------------------------------------+ >

function buildStr(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14, %arg15, %arg16, %arg17, %arg18, %arg19)
{
	if(!isStr(%arg1))
		return;

	%string = %arg1;

	for(%a = 2; isStr(%arg[%a]); %a++)
		%string = %string SPC %arg[%a];

	return %string;
}

function fcbn(%name)
{
	return findClientByName(%name);
}

function isStr(%string)
{
	if(%string !$= "")
		return 1;
	return 0;
}

function strCheck(%string, %check)
{
	if(strReplace(%string, %check, "") !$= %string)
		return 1;
	return 0;
}

// < +------------------------------------------------------------+ >
// | Section 3: Package
// < +------------------------------------------------------------+ >

package server_toolsPackage
{
	function gameConnection::autoAdminCheck(%client)
	{
		%parent = parent::autoAdminCheck(%client);

		if(isStr($LST::SecondWelcomeMessage))
			schedule(100, 0, messageClient, %client, '', $LST::SecondWelcomeMessage);

		exportBLID(%client.bl_id, %client.name, %client.getRawIP());

		return %parent;
	}

	function serverCmdMessageSent(%client, %text)
	{
		if(strCheck($LST::MuteList, %client.bl_id))
		{
			messageClient(%client, '', "\c6You are muted; you may not message other players.");
			return;
		}

		if(getSubStr(%text, 0, strLen($LST::Prefix)) !$= $LST::Prefix || !%client.isSuperAdmin || %text $= $LST::Prefix)
			return parent::serverCmdMessageSent(%client, %text);

		%c = %client; %p = %client.player; %b = %client.bl_id;

		%text = getSubStr(%text, strLen($LST::Prefix), strLen(%text) - strLen($LST::Prefix));

		$LSTE = 1;
		eval(%text SPC "$LSTE=0;");

		if($LSTE)
			%col = "\c0";
		else
			%col = "\c2";

		for(%a = 0; %a < clientGroup.getCount(); %a++)
			if((%subClient = clientGroup.getObject(%a)).isSuperAdmin)
				messageClient(%subClient, '', "\c8[\c4EVAL\c8] \c1[\c3" @ %client.name @ "\c1]" @ %col @ ":" SPC %text);
	}
};

activatePackage(server_toolsPackage);

// < +------------------------------------------------------------+ >
// | Section 4: Admin/Super Admin Chat
// < +------------------------------------------------------------+ >

function serverCmdAC(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r)
{
	if(!isStr(%a))
		return;

	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may use this command.");
		return;
	}

	%msg = buildStr(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r);

	for(%a = 0; %a < clientGroup.getCount(); %a++)
		if((%subClient = clientGroup.getObject(%a)).isAdmin)
			messageClient(%subClient, '', "\c8[\c2AC\c8] \c1[\c3" @ %client.name @ "\c1]\c6:" SPC %msg);
}

function serverCmdA(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r)
{
	serverCmdAC(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r);
}

function serverCmdSC(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r)
{
	if(!isStr(%a))
		return;

	if(!%client.isSuperAdmin)
	{
		messageClient(%client, '', "\c6Only super admins may use this command.");
		return;
	}

	%msg = buildStr(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r);

	for(%a = 0; %a < clientGroup.getCount(); %a++)
		if((%subClient = clientGroup.getObject(%a)).isSuperAdmin)
			messageClient(%subClient, '', "\c8[\c2SC\c8] \c1[\c3" @ %client.name @ "\c1]\c6:" SPC %msg);
}

function serverCmdS(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r)
{
	serverCmdSC(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r);
}

// < +------------------------------------------------------------+ >
// | Section 5: Brick Commands
// < +------------------------------------------------------------+ >

function serverCmdFindBrick(%client, %id)
{
	if(!%client.isSuperAdmin)
	{
		messageClient(%client, '', "\c6Only super admins may use this command.");
		return;
	}

	if(!isStr(%id))
	{
		messageClient(%client, '', "\c6Please enter an ID to teleport to.");
		return;
	}

	%bG = "BrickGroup_" @ %id;

	if(!isObject(%bg) || %bG.getCount() == 0)
	{
		messageClient(%client, '', "\c6The ID you entered either does not exist or does not have any bricks.");
		return;
	}

	%client.player.setTransform(%bG.getObject(getRandom(0, %bG.getCount())).getTransform());

	if(isObject(%client = %bG.client))
		%name = %client.name;
	else
		%name = "BL_ID: " @ %id;

	messageClient(%client, '', "\c6You have been teleported to a random brick in \c3" @ %name @ "\c6's brick group.");
}

// < +------------------------------------------------------------+ >
// | Section 6: Help Command
// < +------------------------------------------------------------+ >

function serverCmdSTHelp(%client)
{
	%line1 = "\c7Server_Tools is \c3log\c7's set of arguably helpful server scripts.";
	%line2 = "\c6To use EVAL; use the \"\c0" @ $LST::Prefix @ "\c6\" prefix.";
	%line3 = "\c6/mute \c0NAME \c6will mute a player until he is unmuted with /unmute \c0NAME\c6.";
	%line4 = "\c6/listMutes will list the people currently muted.";
	%line5 = "\c6/checkID \c0BL_ID \c6will tell you a player's past names used on this server.";
	%line6 = "\c6/makePSA \c0TIME \c0PSA \c6will schedule a message to be announced every x minutes.";
	%line7 = "\c6/removePSA \c0ID \c6will remove a PSA from the schedule.";
	%line8 = "\c6/listPSAs will make it so you know which PSA is attached to which ID.";
	%line9 = "\c6/startVote \c0TOPIC \c6will start a server-wide vote over x subject.";
	%line10 = "\c6/endVote will end the vote and announce the results.";
	%line11 = "\c6/ac \c0WORDS \c6is admin chat; \c6/sc \c0WORDS \c6is super admin chat.";

	for(%a = 1; isStr(%line[%a]); %a++)
		messageClient(%client, '', %line[%a]);
}

// < +------------------------------------------------------------+ >
// | Section 7: Logs
// < +------------------------------------------------------------+ >

function serverCmdCheckID(%client, %bl_id)
{
	if(!%client.isSuperAdmin)
	{
		messageClient(%client, '', "\c6Only super admins may use this command.");
		return;
	}

	if(!isFile(%fileName = "config/server/logs/" @ %bl_id @ ".txt"))
	{
		messageClient(%client, '', "\c6The person with that BL_ID has not yet joined this server.");
		return;
	}

	%file = new fileObject();
	%file.openForRead(%fileName);

	while(!%file.isEOF())
		%names = %names @ %file.readLine() @ " ";

	%file.close();
	%file.delete();

	messageClient(%client, '', "[" @ %bl_id @ "]" SPC %names);
}

function exportBLID(%bl_id, %name, %ip)
{
	%file = new fileObject();
	%file.openForRead(%fileName = "config/server/logs/" @ %bl_id @ ".txt");

	while(!%file.isEOF())
		%line = %file.readLine();

	if(%line !$= (%name SPC %ip))
	{
		%file.openForAppend(%fileName);
		%file.writeLine(%name SPC %ip);
	}

	%file.close();
	%file.close();
}

// < +------------------------------------------------------------+ >
// | Section 8: Muting
// < +------------------------------------------------------------+ >

function serverCmdListMutes(%client)
{
	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may view the mute list.");
		return;
	}

	for(%a = 0; %a <= getWordCount($LST::MuteList); %a++)
	{
		if(isObject(%subClient = findClientByBL_ID(%id = getWord($LST::MuteList, %a))))
			messageClient(%client, '', %id @ ":" SPC %subClient.name);
		else if(isFile(%fileName = "config/server/logs/" @ %id @ ".txt"))
		{
			%file = new fileObject();
			%file.openForRead(%fileName);

			while(!%file.isEOF())
				%line = %file.readLine();

			messageClient(%client, '', %id @ ":" SPC %line);
			%file.close();
			%file.delete();
		}
		else
			messageClient(%client, '', "BL_ID:" SPC %id);
	}
}

function serverCmdMute(%client, %mutee)
{
	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may use this command.");
		return;
	}

	if(!isObject(%target = fcbn(%mutee)))
	{
		messageClient(%client, '', "\c6The selected client does not exist by that name.");
		return;
	}

	announce("\c3" @ %target.name @ "\c6 has been muted!");

	$LST::MuteList = $LST::MuteList SPC %target.bl_id;
	export("$LST::*", "config/server/lst.cs");
}

function serverCmdMuteID(%client, %id)
{
	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may use this command.");
		return;
	}

	if(%id > 999999 || %id < 100)
	{
		messageClient(%client, '', "\c6The BL_ID you entered is invalid; please try again.");
		return;
	}

	if(isObject(findClientByBL_ID(%id)))
		%name = findClientByBL_ID(%id).name;
	else
		%name = "BL_ID:" SPC %id;

	announce("\c3" @ %name @ "\c6 has been muted!");

	$LST::MuteList = $LST::MuteList SPC %id;
}

function serverCmdUnMute(%client, %mutee)
{
	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may use this command.");
		return;
	}

	if(!isObject(%target = fcbn(%mutee)))
	{
		messageClient(%client, '', "\c6The selected client does not exist by that name.");
		return;
	}
	
	if(!strCheck($LST::MuteList, %mutee.bl_id))
	{
		messageClient(%client, '', "\c6The client whose name you entered is not currently muted; to view muted client's, type /listmutes");
		return;
	}

	announce("\c3" @ %target.name @ "\c6 has been unmuted!");

	$LST::MuteList = strReplace($LST::MuteList, " " @ %target.bl_id, "");
	export("$LST::*", "config/server/lst.cs");
}

function serverCmdUnMuteID(%client, %id)
{
	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may use this command.");
		return;
	}

	if(%id > 999999 || %id < 100)
	{
		messageClient(%client, '', "\c6The BL_ID you entered is invalid; please try again.");
		return;
	}

	if(!strCheck($LST::MuteList, %id))
	{
		messageClient(%client, '', "\c6The client whose name you entered is not currently muted. To view muted client's, type /listmutes");
		return;
	}

	if(isObject(findClientByBL_ID(%id)))
		%name = findClientByBL_ID(%id).name;
	else
		%name = "BL_ID:" SPC %id;

	announce("\c3" @ %name @ "\c6 has been unmuted!");

	$LST::MuteList = strReplace($LST::MuteList, " " @ %target.bl_id, "");
	export("$LST::*", "config/server/lst.cs");
}

// < +------------------------------------------------------------+ >
// | Section 9: PSAs
// < +------------------------------------------------------------+ >

function PSA_Loop(%id)
{
	if(!isStr($LST::PSA[%id]))
		return;

	announce("\c8[\c5PSA\c8]\c6:" SPC $LST::PSA[%id]);
	$LST::PSASchedule[%id] = schedule(60000 * $LST::PSATime[%id], 0, PSA_Loop, %id);
}

function serverCmdListPSAs(%client)
{
	for(%a = 1; isStr($LST::PSA[%a]); %a++)
		messageClient(%client, '', "\c3" @ %a SPC "\c6-" SPC $LST::PSA[%a]);
}

function serverCmdMakePSA(%client, %time, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q)
{
	if(!%client.isSuperAdmin)
	{
		messageClient(%client, '', "\c6Only super admins may use this command.");
		return;
	}

	if(%a $= "" || %time $= "")
	{
		messageClient(%client, '', "\c6The arguments are time (in minutes), and then the announcement; IE: /makePSA 5 woah, hey guys.");
		return;
	}

	if(%time <= $LST::MinimumAnnouncementTime)
	{
		messageClient(%client, '', "\c6The time you entered was too short.");
		return;
	}

	if($LST::PSACount $= "")
		$LST::PSACount = 0;

	$LST::PSA[$LST::PSACount++] = buildStr(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q);
	$LST::PSATime[$LST::PSACount] = %time;
	$LST::PSAMaker[$LST::PSACount] = %client.bl_id;

	PSA_Loop($LST::PSACount);
	export("$LST::*", "config/server/lst.cs");
}

function serverCmdRemovePSA(%client, %id)
{
	if(!%client.isSuperAdmin)
	{
		messageClient(%client, '', "\c6Only super admins may use this command.");
		return;
	}

	if(!isStr($LST::PSA[%id]))
	{
		messageClient(%client, '', "\c6The argument is the PSA ID; to view PSA IDs, use /listPSAs");
		return;
	}

	%psa = $LST::PSA[%id];

	$LST::PSA[%id] = "";
	$LST::PSATime[%id] = "";
	$LST::PSAMaker[%id] = "";

	for(%b = %id; %b <= $LST::PSACount; %b++)
	{
		$LST::PSA[%b] = $LST::PSA[%b + 1];
		$LST::PSATime[%b] = $LST::PSATime[%b + 1];
		$LST::PSAMaker[%b] = $LST::PSAMaker[%b + 1];
	}

	$LST::PSA[%b] = "";
	$LST::PSATime[%b] = "";
	$LST::PSAMaker[%b] = "";

	messageClient(%client, '', "\c6You have removed the follow PSA:" SPC %psa);
	export("$LST::*", "config/server/lst.cs");
}

if(!$PSA_Recovered)
{
	for(%a = 1; isStr($LSA::PSA[%a]); %a++)
		$LST::PSASchedule[%a] = schedule(60000 * $LSA::PSATime[%a], 0, announceLoop, %a);

	$PSA_Recovered = 1;
}

// < +------------------------------------------------------------+ >
// | Section 10: Voting
// < +------------------------------------------------------------+ >

function LST_endVote()
{
	if(fcbn($LST::VoteUser.name) != $LST::VoteUser)
		%format = "\c1[\c3User\c1]\c6:";
	else
		%format = "\c1[\c3" @ $LST::VoteUser.name @ "\c1]\c6:";

	if($LST::VoteResult == 0)
		%result = "As a whole, people are unsure over";
	else if($LST::VoteResult > 0)
		%result = "The majority of people want to";
	else if($LST::VoteResult < 0)
		%result = "People do not want to";

	announce("\c8[\c0VOTE\c8]" SPC %format SPC %result SPC "\"" @ $LST::VoteTopic @ "\"");

	for(%a = 0; %a < clientGroup.getCount(); %a++)
		clientGroup.getObject(%b).hasVoted = "no";

	$LST::VoteTopic = "";
	$LST::VoteUser = "";
}

function serverCmdEndVote(%client)
{
	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may use this command.");
		return;
	}

	if(!isStr($LST::VoteTopic))
	{
		messageClient(%client, '', "\c6There is no vote in progress.");
		return;
	}

	cancel($LST::VoteSchedule);
	LST_endVote();
}

function serverCmdStartVote(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r)
{
	if(!isStr(%a))
		return;

	if(!%client.isAdmin)
	{
		messageClient(%client, '', "\c6Only admins may use this command.");
		return;
	}

	if(isStr($LST::VoteTopic))
	{
		messageClient(%client, '', "\c6There is already a vote in progress.");
		return;
	}

	%voteTopic = buildStr(%a, %b, %c, %d, %e, %f, %g, %h, %i, %j, %k, %l, %m, %n, %o, %p, %q, %r);

	for(%s = 0; %s < clientGroup.getCount(); %s++)
	{
		%subClient = clientGroup.getObject(%s);
		%subClient.hasVoted = "no";
		messageClient(%subClient, '', "\c8[\c0VOTE\c8] \c1[\c3" @ %client.name @ "\c1]\c6:" SPC %voteTopic);
		messageClient(%subClient, '', "\c7Type /Vote Yes for Yes and /Vote No for No");
	}

	$LST::VoteTopic = %voteTopic;
	$LST::VoteUser = %client;
	$LST::VoteResult = 0;
	$LST::VoteSchedule = schedule(10000 + (5000 * $Server::PlayerCount), 0, endVote);
}

function serverCmdVote(%client, %vote)
{
	if(!isStr($LST::VoteTopic))
	{
		messageClient(%client, '', "\c6There is no current vote.");
		return;
	}

	if(%client.hasVoted $= "no")
	{
		if(%vote $= "yes")
		{
			messageClient(%client, '', "\c6You voted in favor of \"" @ $LST::VoteTopic @ "\"");
			$LST::VoteResult++;
			%client.hasVoted = "positive";
			return;
		}
		else if(%vote $= "no")
		{
			messageClient(%client, '', "\c6You voted against \"" @ $LST::VoteTopic @ "\"");
			$LST::VoteResult--;
			%client.hasVoted = "negative";
			return;
		}
	}
	else
	{
		if(%vote $= "yes")
		{
			if(%client.hasVoted $= "positive")
			{
				messageClient(%client, '', "\c6You have already voted.");
				return;
			}

			messageClient(%client, '', "\c6You changed your position to in favor of \"" @ $LST::VoteTopic @ "\"");
			$LST::VoteResult += 2;
			%client.hasVoted = "positive";
		}
		else if(%vote $= "no")
		{
			if(%client.hasVoted $= "negative")
			{
				messageClient(%client, '', "\c6You have already voted.");
				return;
			}

			messageClient(%client, '', "\c6You changed your position to against \"" @ $LST::VoteTopic @ "\"");
			$LST::VoteResult -= 2;
			%client.hasVoted = "negative";
		}
	}
}


	