// < +--------------------------------------+ >
// | Project: BLIDChatLogger : client.cs
// | Description: Logs BL_IDs, names, and chat.
// | Author: Aoki
// < +--------------------------------------+ >

package BLIDChatLoggingPackage
{
	function NMH_Type::Send(%this)
	{
		%text = %this.getValue();
		%text = strReplace(%text, "https://", "http://");

		if(getSubStr(%text, 0, 1) !$= "^")
		{
			parent::send(%this);
			return;
		}

		if(firstWord(%text) $= "^recallID")
		{
			%bl_id = getWord(%text, 1);

			if(%bl_id > 999999 || %bl_id < 100)
				%dontDoIt = 1;

			%fileName = "config/client/BCL/data/" @ %bl_id @ ".txt";

			if(!isFile(%fileName))
				%dontDoIt = 1;

			if(!%dontDoIt)
			{
				%file = new fileObject();
				%file.openForRead(%fileName);
				while(!%file.isEOF()) {
					%names = %names @ %file.readLine() @ " "; }
				%file.close();
				%file.delete();
				%msg = "\c3" @ %bl_id @ "\c6:" SPC %names;
				newChatSO.addLine(%msg);
				%didStuff = 1;
			}
		}
		else if(firstWord(%text) $= "^recallName")
		{
			%bl_id = $BCL::BL_ID[restWords(%text)];

			if(%bl_id > 999999 || %bl_id < 100)
				%dontDoIt = 1;

			%fileName = "config/client/BCL/data/" @ %bl_id @ ".txt";

			if(!isFile(%fileName))
				%dontDoIt = 2;

			if(!%dontDoIt)
			{
				%file = new fileObject();
				%file.openForRead(%fileName);
				while(!%file.isEOF()) {
					%names = %names @ %file.readLine() @ " "; }
				%file.close();
				%file.delete();
				%msg = "\c3" @ %bl_id @ "\c6:" SPC %names;
				newChatSO.addLine(%msg);
				%didStuff = 1;
			}
		}

		if(%dontDoIt == 1)
			newChatSO.addLine("\c3" @ %bl_id @ "\c6:" SPC "No names found.");
		else if(%dontDoIt == 2)
			newChatSO.addLine("\c6No BL_ID with that name is on your server.");

		if(!%didStuff && !%dontDoIt)
			%this.setValue(%text);
		else
			%this.setValue("");

		parent::send(%this);
	}

	function clientcmdChatMessage(%a, %b, %c, %fmsg, %cp, %name, %cs, %msg)
	{
		if(BCL_isStr(%name) && BCL_isStr(%msg))
			echo(%name @ ":" SPC stripMlControlChars(%msg));

        		Parent::clientcmdChatMessage(%a, %b, %c, %fmsg, %cp, %name, %cs, %msg);

		if(!BCL_isStr(%name) || !BCL_isStr(%msg))
			return;

		BCL_loopExportChat(%name, stripMLControlChars(%msg));
	}

	function newPlayerListGui::update(%this, %cl, %name, %BL_ID, %trust, %admin, %score)
	{
		Parent::update(%this, %cl, %name, %BL_ID, %trust, %admin, %score);
		BCL_exportBLID(%BL_ID, %name, %admin);
		$BCL::BL_ID[%name] = %BL_ID;
	}

	function disconnect()
	{
		parent::disconnect();
		deleteVariables("$BCL::*");
	}
};

function BCL_isStr(%str)
{
	if(%str !$= "")
		return 1;
	return 0;
}

function BCL_strCheck(%str, %chk)
{
	if(strReplace(%str, %chk, "") !$= %str)
		return 1;
	return 0;
}

function BCL_exportBLID(%BL_ID, %name, %admin)
{
	if(%BL_ID > 999999 || %BL_ID < 100)
		return;

	%fileName = "config/client/BCL/data/" @ %BL_ID @ ".txt";
	%fileWrite = %name;
	%file = new FileObject();
	%file.openForRead(%fileName);
	while(!%file.isEOF()) {
		%line = %file.readLine(); }
	if(%line !$= %fileWrite)
	{
		%file.openForAppend(%fileName);
		%file.writeLine(%fileWrite);
	}
	%file.close();
	%file.delete();
}

function BCL_loopExportChat(%name, %chat)
{
	if(!BCL_strCheck($ServerInfo::Name, "\'"))
	{
		$BCL::hasExported = 0;
		if(BCL_isStr(%name) && BCL_isStr(%chat))
		{
			if(!BCL_isStr($BCL::lzMsg[1]))
				$BCL::lzMsgCount = 0;

			$BCL::lzMsg[$BCL::lzMsgCount++] = %chat;
			$BCL::lzName[$BCL::lzMsgCount] = %name;

			schedule(1000, 0, BCL_loopExportChat);
		}
	}
	else
	{
		if(!$BCL::hasExported)
		{
			for(%a = 1; %a <= $BCL::lzMsgCount; %a++)
			{
				BCL_exportChat($BCL::lzName[%a], $BCL::lzMsg[%a]);
			}
			$BCL::hasExported = 1;
		}
		BCL_exportChat(%name, %chat);
	}
}

function BCL_exportChat(%name, %chat)
{
	%date = strReplace(getWord(getDateTime(), 0), "/", "-");
	%stupidClock = getSubStr(getDateTime(), 9, 2);

	if(%stupidClock > 12)
	{
		%stupidClock -= 12;
		%hasTurned = 1;
	}
		
	%time = %stupidClock @ ":" @ getSubStr(getDateTime(), 12, 2);

	if(%hasTurned)
		%time = %time SPC "PM";
	else
		%time = %time SPC "AM";

	%servName = $ServerInfo::Name;
	//the next line was taken from Curse's chat logging mod.
	%servName = (getSubstr(%servName,strStr(%servName,"\'")+1,1) $= "s") ? %servname = getSubstr(%servname,strStr(%servname,"-")+2,strStr(%servname,"'s")-strStr(%servname,"-")) : %servname = getSubstr(%servname,strStr(%servname,"-")+2,strStr(%servname,"'")-strStr(%servname,"-"));
	//this line is fixing a problem the line before made.
	%servName = getSubStr($ServerInfo::Name, 0, 1) @ %servName;
	%file = new fileObject();
	%file.openForAppend("config/client/BCL/chatLogs/" @ %servName @ " Server" @ "/" @ %date @ ".txt");
	%file.writeLine("[" @ %time @ "]" @ "[" @ $BCL::BL_ID[%name] @ "]" SPC %name @ ":" SPC %chat);
	%file.close();
	%file.delete();		
}

activatePackage(BLIDChatLoggingPackage);

	