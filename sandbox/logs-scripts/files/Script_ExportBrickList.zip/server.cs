function servercmdExportBrickList(%client)
{
	if(!%client.isSuperAdmin)
	{
		messageClient(%client, '', "\c6You must be a Super Admin or higher to use this command.");
		return 0;
	}

	if(getBrickCount() <= 0)
	{
		messageClient(%client, '', "\c6There are no bricks on this server.");
		return 0;
	}

	%objectCount = 0;
	%groupCount = MainBrickGroup.getCount();

	for(%a = 0; %a < %groupCount; %a++)
	{
		%group = MainBrickGroup.getObject(%a);
		%count = %group.getCount();

		for(%b = 0; %b < %count; %b++)
		{
			%brick = %group.getObject(%b);

			if(!(%brick.getType() & $TypeMasks::FxBrickAlwaysObjectType) || !%brick.isPlanted || %brick.isDead)
				continue;

			%brickData = %brick.getDatablock().getID();

			if(%id[%brickData.uiName SPC getColorIDTable(%brick.colorID)] $= "")
			{
				%group[%objectCount] = %brickData.uiName SPC getColorIDTable(%brick.colorID);
				%id[%group[%objectCount]] = %objectCount;
				%count[%group[%objectCount]]++;
				%objectCount++;
			}
			else
				%count[%group[%id[%brickData.uiName SPC getColorIDTable(%brick.colorID)]]]++;
		}
	}

	%file = new fileObject();
	%file.openForWrite("config/brickList.txt");

	for(%c = 0; %c <= %objectCount; %c++)
	{
		%file.writeLine(%count[%group[%c]] SPC %group[%c]);
		%file.writeLine("");
	}

	%file.close();
	%file.delete();

	messageAll('', "\c6A list of bricks has been exported to \c3/config/BrickList.txt\c6.");
}