// < +------------------------------------------------------------+ >
// | Project: Script_LoadOut : package.cs
// | Description: Overwrites functions to create script functionality
// | Author: Aoki
// < +------------------------------------------------------------+ >

package LOPackage
{
	function gameConnection::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA)
	{
		%client.LoadOut = %client.player.tool[0].getID();

		for(%a = 1; %client.player.tool[%a].uiName !$= ""; %a++)
		%client.LoadOut = %client.LoadOut SPC %client.player.tool[%a].getID();

		Parent::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA);
	}

	function gameConnection::spawnPlayer(%client)
	{
		%parent = parent::spawnPlayer(%client);

		if(%client.LoadOut !$= "")
		{
			for(%b = 0; getWord(%client.LoadOut, %b) !$= ""; %b++)
			{
				%client.player.tool[%b] = getWord(%client.LoadOut, %b);
				messageClient(%client, 'MsgItemPickup', '', %b, getWord(%client.LoadOut, %b));
			}

			messageClient(%client, '', "\c6Your previous items have been loaded.");
		}

		return %parent;
	}
};

activatePackage(LOPackage);