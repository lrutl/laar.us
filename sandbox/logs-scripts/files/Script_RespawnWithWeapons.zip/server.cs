// < +------------------------------------------------------------+ >
// | Project: Script_LoadOut : server.cs
// | Description: Executes the required files.
// | Author: Aoki
// < +------------------------------------------------------------+ >

exec("./package.cs");

			
	